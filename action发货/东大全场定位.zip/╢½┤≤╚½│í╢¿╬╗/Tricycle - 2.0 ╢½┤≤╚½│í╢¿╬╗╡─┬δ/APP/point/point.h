#ifndef __POINT_H
#define __POINT_H

void track_point();

#endif