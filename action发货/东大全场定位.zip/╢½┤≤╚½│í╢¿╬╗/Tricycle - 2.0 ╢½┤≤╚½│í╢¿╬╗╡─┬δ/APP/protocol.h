#ifndef __PCONTROL_H
#define __PCONTROL_H
#include "sys.h"

void Prepare_Data_1(void);


#endif
